﻿//***********************************************************************************************************

// This page i've created and writting the ADO conections that's an another way of implemenation in the development 

//***********************************************************************************************************

using Gov2Biz_CFS_DINESH_G.Migrations;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Gov2Biz_CFS_DINESH_G.Models
{
    public class AdoConnection
    {
        //string connectionString = "Data Source=.;Initial Catalog=Gov2BizCFS;Integrated Security=True;Trust Server Certificate=True;";

        ////To View all CustomerFeedback details    
        //public IEnumerable<CustomerFeedback> GetAllCustomerFeedback()
        //{
        //    List<CustomerFeedback> lstCustomerFeedback = new List<CustomerFeedback>();

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("US_gov2biz_SP_GetAllCustomerFeedback", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        con.Open();
        //        SqlDataReader rdr = cmd.ExecuteReader();

        //        while (rdr.Read())
        //        {
        //            CustomerFeedback customerFeedback = new CustomerFeedback();

        //            customerFeedback.FeedbackId = Convert.ToInt32(rdr["FeedbackId"]);
        //            customerFeedback.CustomerName = rdr["CustomerName"].ToString();
        //            customerFeedback.EmailAddress = rdr["EmailAddress"].ToString();
        //            customerFeedback.FeedbackType = rdr["FeedbackType"].ToString();
        //            customerFeedback.FeedbackMessage = rdr["FeedbackMessage"].ToString();
        //            customerFeedback.CreatedOn = rdr["CreatedOn"].ToString();

        //            lstCustomerFeedback.Add(customerFeedback);
        //        }
        //        con.Close();
        //    }
        //    return lstCustomerFeedback;
        //}

        ////To Add new customerFeedback record    
        //public void AddcustomerFeedback(CustomerFeedback customerFeedback)
        //{
        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("US_gov2biz_SP_spAddcustomerFeedback", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@CustomerName", customerFeedback.CustomerName);
        //        cmd.Parameters.AddWithValue("@EmailAddress", customerFeedback.EmailAddress);
        //        cmd.Parameters.AddWithValue("@FeedbackType", customerFeedback.FeedbackType);
        //        cmd.Parameters.AddWithValue("@FeedbackMessage", customerFeedback.FeedbackMessage);
        //        cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);

        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //        con.Close();
        //    }
        //}

        ////To Update the records of a particluar customerFeedback  
        //public void UpdatecustomerFeedback(CustomerFeedback customerFeedback)
        //{
        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("US_gov2biz_SP_UpdateCustomerFeedback", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@FeedbackId", customerFeedback.FeedbackId);
        //        cmd.Parameters.AddWithValue("@CustomerName", customerFeedback.CustomerName);
        //        cmd.Parameters.AddWithValue("@EmailAddress", customerFeedback.EmailAddress);
        //        cmd.Parameters.AddWithValue("@FeedbackType", customerFeedback.FeedbackType);
        //        cmd.Parameters.AddWithValue("@FeedbackMessage", customerFeedback.FeedbackMessage);
        //        cmd.Parameters.AddWithValue("@CreatedOn", DateTime.Now);


        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //        con.Close();
        //    }
        //}

        ////Get the details of a particular customerFeedback  
        //public CustomerFeedback GetcustomerFeedbackData(int? id)
        //{
        //    CustomerFeedback customerFeedback = new CustomerFeedback();

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        string sqlQuery = "SELECT * FROM CustomerFeedback WHERE FeedbackId= " + id;
        //        SqlCommand cmd = new SqlCommand(sqlQuery, con);

        //        con.Open();
        //        SqlDataReader rdr = cmd.ExecuteReader();

        //        while (rdr.Read())
        //        {   
        //            customerFeedback.FeedbackId = Convert.ToInt32(rdr["FeedbackId"]);
        //            customerFeedback.CustomerName = rdr["CustomerName"].ToString();
        //            customerFeedback.EmailAddress = rdr["EmailAddress"].ToString();
        //            customerFeedback.FeedbackType = rdr["FeedbackType"].ToString();
        //            customerFeedback.FeedbackMessage = rdr["FeedbackMessage"].ToString();
        //            customerFeedback.CreatedOn = rdr["CreatedOn"].ToString();
        //        }
        //    }
        //    return customerFeedback;
        //}

        ////To Delete the record on a particular customerFeedback
        //public void DeletecustomerFeedback(int? id)
        //{

        //    using (SqlConnection con = new SqlConnection(connectionString))
        //    {
        //        SqlCommand cmd = new SqlCommand("US_gov2biz_SP_DeleteCustomerFeedback", con);
        //        cmd.CommandType = CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@FeedbackId", id);

        //        con.Open();
        //        cmd.ExecuteNonQuery();
        //        con.Close();
        //    }
        //}
    }
}

