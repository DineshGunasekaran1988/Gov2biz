﻿// <copyright file="CustomerFeedBackDetails.cs" company="gov2biz - US">
//   Copyright (c) gov2biz- US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------


using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.AspNetCore.Routing.Constraints;
using System.ComponentModel.DataAnnotations;
using System.Reflection;

namespace Gov2Biz_CFS_DINESH_G.Models
{
    /// <summary>
    /// These below variables are used to play the CRUD operation in the database for Customer feedback details table.
    /// </summary>
    public class CustomerFeedBackDetails
    {
        /// <summary>
        /// Gets the Customername to display/Edit.
        /// </summary>
        [Required]
        public string CustomerName { get; set; } = "";

        /// <summary>
        /// Gets the eMail Address to display/Edit.
        /// </summary>
        [Required]
        [EmailAddress]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
                ErrorMessage = "Please enter a valid e-mail address")]
        public string EmailAddress { get; set; } = "";

        /// <summary>
        /// Gets the Feedback type to display/Edit.
        /// </summary>
        [Required]
        public string FeedbackType { get; set; } = "";

        /// <summary>
        /// Gets the Feedback Message type to display/Edit.
        /// </summary>
        [Required]
        [StringLength(maximumLength: 10000, MinimumLength = 50)]
        public string FeedbackMessage { get; set; } = "";


        /// <summary>
        /// Gets the App Version to display/Edit.
        /// </summary>
        [Required]
        [RegularExpression(@"^([0-9]+).([0-9]+).([0-9]+).([0-9]+)", ErrorMessage = "Please enter a valid App Version (EX: 1.1.1.1)")]
        public string AppVersion { get; set; } = "";

        /// <summary>
        /// Read the date of customer details created on with date and time format.
        /// </summary>
        public DateTime CreatedOn { get; set; }
    }
}
