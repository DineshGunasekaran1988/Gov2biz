// <copyright file="CustomerFeedBackController.cs" company="gov2biz - US">
//   Copyright (c) gov2biz- US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Gov2Biz_CFS_DINESH_G.Models
{
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}