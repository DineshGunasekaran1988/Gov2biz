﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CustomerFeedBackController.cs" company="gov2biz - US">
//   Copyright (c) gov2biz- US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using Gov2Biz_CFS_DINESH_G.Models;
using Gov2Biz_CFS_DINESH_G.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace Gov2Biz_CFS_DINESH_G.Controllers
{
    public class CustomerFeedBackController : Controller
    {
        private readonly ApplicationDBContext _dbContext;
        public CustomerFeedBackController(ApplicationDBContext context)
        {
            this._dbContext = context;
        }

        /// <summary>
        /// To View all CustomerFeedback details
        /// This is our home page with all the customer feedback details are displayed based on from the recent created records shows first.
        /// </summary>
        public IActionResult Index() // Read  All Customer Feedback Details
        {
            try
            {
                var customerfeedback = _dbContext.CustomerFeedbacks.OrderByDescending(c => c.CreatedOn).ToList();
                return View(customerfeedback);
            }
            catch (Exception ex)
            {   
                return StatusCode(500, ex.Message);                
            }           
        }

        /// <summary>
        /// To Add new customerFeedback record  
        /// Here we'll load all the Input details of customer feedback details and then display as form.
        /// </summary>
        public IActionResult Create() 
        {
            try
            {
                return View();
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        /// <summary>
        /// once we Added the new records then it will open the customerFeedback deatils page
        /// Create the new customer feedback from this instance is contained in
        /// </summary>
        [HttpPost]
        public IActionResult Create(CustomerFeedBackDetails customerFeedBackDetails)     //To Add new customerFeedback record    
        {
            try
            {               
                if (!ModelState.IsValid)
                {
                    return View(customerFeedBackDetails);
                }

                //Create new record of Customer Feedback deatils
                CustomerFeedback customerFeedback = new CustomerFeedback()
                {
                    CustomerName = customerFeedBackDetails.CustomerName,
                    EmailAddress = customerFeedBackDetails.EmailAddress,
                    FeedbackType = customerFeedBackDetails.FeedbackType,
                    FeedbackMessage = customerFeedBackDetails.FeedbackMessage,
                    AppVersion = customerFeedBackDetails.AppVersion,
                    CreatedOn = DateTime.Now,
                };

                _dbContext.CustomerFeedbacks.Add(customerFeedback);
                _dbContext.SaveChanges();

                return RedirectToAction("Index", "CustomerFeedBack");

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        /// Edit the existing customer feedback details based on selction by feedbackID
        /// </summary>
        public IActionResult Edit(int Id)   //To Update the records of a particluar customerFeedback  
        {
            try
            {
                var customerFeedback = _dbContext.CustomerFeedbacks.Find(Id);

                if (customerFeedback == null)
                {
                    return RedirectToAction("Index", "CustomerFeedBack");
                }

                //Create new record of Customer Feedback deatils
                var CustomerFeedBackDetails = new CustomerFeedBackDetails()
                {
                    CustomerName = customerFeedback.CustomerName,
                    EmailAddress = customerFeedback.EmailAddress,
                    FeedbackType = customerFeedback.FeedbackType,
                    FeedbackMessage = customerFeedback.FeedbackMessage,
                    AppVersion = customerFeedback.AppVersion,
                    CreatedOn = DateTime.Now,
                };

                ViewData["CustomerFeedbackId"] = customerFeedback.FeedbackId;
                ViewData["CreatedOn"] = customerFeedback.CreatedOn;

                return View(CustomerFeedBackDetails);

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }


        /// <summary>
        /// Once the Edit has been done for the existing customer feedback details and this will save the changes into the database table.
        /// </summary>
        [HttpPost]
        public IActionResult Edit(int Id, CustomerFeedBackDetails customerFeedBackDetails)  //To Update and save the records of a particluar customerFeedback  
        {
            try
            {
                var customerFeedback = _dbContext.CustomerFeedbacks.Find(Id);

                if (customerFeedback == null)
                {
                    return RedirectToAction("Index", "CustomerFeedBack");
                }

                if (!ModelState.IsValid)
                {
                    ViewData["CustomerFeedbackId"] = customerFeedback.FeedbackId;
                    ViewData["CreatedOn"] = customerFeedback.CreatedOn;

                    return View(customerFeedBackDetails);
                }

                //Update the existing customer Feedback details
                customerFeedback.CustomerName = customerFeedBackDetails.CustomerName;
                customerFeedback.EmailAddress = customerFeedBackDetails.EmailAddress;
                customerFeedback.FeedbackType = customerFeedBackDetails.FeedbackType;
                customerFeedback.FeedbackMessage = customerFeedBackDetails.FeedbackMessage;
                customerFeedback.AppVersion = customerFeedBackDetails.AppVersion;
                customerFeedback.CreatedOn = DateTime.Now;

                _dbContext.SaveChanges();

                return RedirectToAction("Index", "CustomerFeedBack");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }

        /// <summary>
        /// If we don't want the feedback details records then we'll remove the data from the database table and save the changes.
        /// </summary>
        public IActionResult Delete(int Id)     //To Delete the record on a particular customerFeedback
        {
            try
            {
                var customerFeedback = _dbContext.CustomerFeedbacks.Find(Id);

                if (customerFeedback == null)
                {
                    return RedirectToAction("Index", "CustomerFeedBack");
                }

                //Create new record of Customer Feedback deatils
                
                _dbContext.CustomerFeedbacks.Remove(customerFeedback);
                _dbContext.SaveChanges(true);

                return RedirectToAction("Index", "CustomerFeedBack");

            }
            catch (Exception ex)
            {
                return StatusCode(500, ex.Message);
            }
        }



    }
}