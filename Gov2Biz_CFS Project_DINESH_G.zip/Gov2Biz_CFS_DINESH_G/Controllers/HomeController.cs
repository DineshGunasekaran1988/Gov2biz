﻿// <copyright file="HomeController.cs" company="gov2biz - US">
//   Copyright (c) gov2biz- US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using Gov2Biz_CFS_DINESH_G.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Gov2Biz_CFS_DINESH_G.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}