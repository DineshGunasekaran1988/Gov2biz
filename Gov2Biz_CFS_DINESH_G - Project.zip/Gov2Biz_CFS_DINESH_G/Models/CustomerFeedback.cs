﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CustomerFeedback.cs" company="Gov2biz - US">
//   Copyright (c) Gov2biz US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace Gov2Biz_CFS_DINESH_G.Models
{
    /// <summary>
    /// These below variables are used to display the customer feedback details.
    /// </summary>
    public class CustomerFeedback
    {
        /// <summary>
        /// Create the feedback ID field in the customer feedback table.
        /// </summary>
        [Key]
        public int FeedbackId { get; set; }

        /// <summary>
        /// Create the Customer Name field in the customer feedback table.
        /// </summary>
        [MaxLength(255)]
        public string CustomerName { get; set; } = "";

        /// <summary>
        /// Create the Email Address field in the customer feedback table.
        /// </summary>
        [MaxLength(255)]        
        public string EmailAddress { get; set; } = "";

        /// <summary>
        /// Create the Feedback Type field in the customer feedback table.
        /// </summary>
        [MaxLength(255)]
        public string FeedbackType { get; set; } = "";

        /// <summary>
        /// Create the Feedback Message field in the customer feedback table.
        /// </summary>                
        public string FeedbackMessage { get; set; } = "";

        /// <summary>
        /// Create the App Version field in the customer feedback table.
        /// </summary>                
        [MaxLength(100)]
        public string AppVersion { get; set; } = "";

        /// <summary>
        /// Create the CreatedOn field in the customer feedback table.
        /// </summary>                
        public DateTime CreatedOn { get; set; }
    }
}


