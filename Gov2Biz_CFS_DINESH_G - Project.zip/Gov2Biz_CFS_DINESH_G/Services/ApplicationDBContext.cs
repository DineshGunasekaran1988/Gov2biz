﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ApplicationDBContext.cs" company="Gov2biz - US">
//   Copyright (c) Gov2biz US. All rights reserved.
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

using Gov2Biz_CFS_DINESH_G.Models;
using Microsoft.EntityFrameworkCore;

namespace Gov2Biz_CFS_DINESH_G.Services
{
    public class ApplicationDBContext : DbContext
    {
        public ApplicationDBContext(DbContextOptions options)  : base(options)
        {

        }

        // As long as I'm using the Entity Framework so that we need not do anything to prevent SQL injection its already in the place.
        public DbSet <CustomerFeedback> CustomerFeedbacks { get; set; }


    }
}
